<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () { return view('index'); });
Route::get('/test', function () { return view('test'); });
Route::get('/account/account-archived-ads', function () { return view('account.account-archived-ads'); });
Route::get('/account/account-close', function () { return view('account.account-close'); });
Route::get('/account/account-favourite-ads', function () { return view('account.account-favourite-ads'); });
Route::get('/account/account-home', function () { return view('account.account-home'); });
Route::get('/account/account-myads', function () { return view('account.account-myads'); });
Route::get('/account/account-pending-approval-ads', function () { return view('account.account-pending-approval-ads'); });
Route::get('/account/account-saved-search', function () { return view('account.account-saved-search'); });


Route::get('/about-us', function () { return view('common.about-us'); });
Route::get('/faq','pagesController@faq');
Route::get('/contact','pagesController@contact');
Route::post('/postContact','pagesController@createContact');



//Route::get('/login', function () { return view('common.login'); });
Route::get('/common/signup', function () { return view('common.signup'); });



Route::get('/jobs/job-details', function () { return view('jobs.job-details'); });
Route::get('/jobs/job-home', function () { return view('jobs.job-home'); });
Route::get('/jobs/job-list', function () { return view('jobs.job-list'); });
Route::get('/jobs/job-login', function () { return view('jobs.job-login'); });
Route::get('/jobs/job-post', function () { return view('jobs.job-post'); });
Route::get('/jobs/job-signup', function () { return view('jobs.job-signup'); });


Route::get('/service/ads-details', function () { return view('service.ads-details'); });
Route::get('/service/ads-details-automobile', function () { return view('service.ads-details-automobile'); });
Route::get('/service/category', function () { return view('service.category'); });
Route::get('/service/post-ads', function () { return view('service.post-ads'); });
Route::get('/service/posting-success', function () { return view('service.posting-success'); });
Route::get('/service/seller-profile', function () { return view('service.seller-profile'); });
Route::get('/service/sub-category-sub-location', function () { return view('service.sub-category-sub-location'); });


Auth::routes();
Route::get('register/verify/{confirmationCode}', [
    'as' => 'confirmation_path',
    'uses' => 'Auth\RegisterController@confirm'
]);

Route::get('/home', function () { return view('index'); });


//////////////
Route::get('/categories', 'MainCatController@index'); /*... return all categories and sub categories ...*/
Route::get('/popularCategories', 'MainCatController@getPopularCategories'); /*... return all popular categories ...*/
Route::get('/category/{category_id}', 'MainCatController@getCategoryById'); /*... return all categories and sub categories ...*/


Route::get('/areas', 'AreaController@index'); /*... return all categories and sub categories ...*/
Route::get('/popularAreas', 'AreaController@getPopularAreas'); /*... return all popular areas ...*/

Route::get('/featuredListings', 'QuickSaleController@index'); /*... return all popular areas ...*/




