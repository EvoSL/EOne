<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index');


//////////////
Route::get('/categories', 'MainCatController@index'); /*... return all categories and sub categories ...*/
Route::get('/popularCategories', 'MainCatController@getPopularCategories'); /*... return all popular categories ...*/
Route::get('/category/{category_id}', 'MainCatController@getCategoryById'); /*... return all categories and sub categories ...*/


Route::get('/areas', 'AreaController@index'); /*... return all categories and sub categories ...*/
Route::get('/popularAreas', 'AreaController@getPopularAreas'); /*... return all popular areas ...*/

Route::get('/featuredListings', 'QuickSaleController@index'); /*... return all popular areas ...*/




