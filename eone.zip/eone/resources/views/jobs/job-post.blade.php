<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="../assets/ico/favicon.png">
    <title>BOOTCLASIFIED - Responsive Classified Theme</title>
    <!-- Bootstrap core CSS -->
    <link href="../assets/bootstrap/css/bootstrap.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css"/>

    <!-- styles needed for carousel slider -->
    <link href="../assets/css/owl.carousel.css" rel="stylesheet">
    <link href="../assets/css/owl.theme.css" rel="stylesheet">

    <!-- Just for debugging purposes. -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- include pace script for automatic web page progress bar  -->

    <script>
        paceOptions = {
            elements: true
        };
    </script>
    <script src="../assets/js/pace.min.js"></script>
</head>
<body>
<div id="wrapper">
    <div class="header">
        <nav class="navbar   navbar-site navbar-default" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span
                            class="icon-bar"></span> <span class="icon-bar"></span></button>
                    <a href="job-home.blade.php" class="navbar-brand logo logo-title">
                        <!-- Original Logo will be placed here  -->
                        <span class="logo-icon"><i class="icon icon-search-1 ln-shadow-logo shape-0"></i> </span>
                        JOB<span>CLASSIFIED </span> </a></div>
                <div class="navbar-collapse collapse">

                    <ul class="nav navbar-nav navbar-left">


                        <li><a href="job-list.blade.php">Browse Jobs</a></li>
                        <li><a href="">Add Resume</a></li>

                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="login.html">Login</a></li>
                        <li><a href="signup.html">Signup</a></li>
                        <li class="postadd"><a class="btn btn-block   btn-border btn-post btn-danger"
                                               href="job-post.blade.php">Post A Job</a></li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
    </div>
    <!-- /.header -->
    <div class="main-container">
        <div class="container">
            <div class="row">
                <div class="col-md-9 page-content">
                    <div class="inner-box category-content">
                        <h2 class="title-2 uppercase"><strong> <i class="icon-briefcase"></i> Post a Job </strong></h2>

                        <div class="row">
                            <div class="col-sm-12">
                                <form class="form-horizontal">
                                    <fieldset>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="CompanyName">Company</label>

                                            <div class="col-md-8">
                                                <input id="CompanyName" name="CompanyName" placeholder="Company Name"
                                                       class="form-control input-md" required="" type="text">
                                            </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="jobTitle">Job Title</label>

                                            <div class="col-md-8">
                                                <input id="jobTitle" name="jobTitle" placeholder="job Title"
                                                       class="form-control input-md" required="" type="text">
                                                <span class="help-block">A great title needs at least 60 characters. </span>
                                            </div>
                                        </div>

                                        <!-- Select Basic -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Category</label>

                                            <div class="col-md-8">
                                                <select name="category-group" id="category-group" class="form-control">
                                                    <option value="0" selected="selected"> Select a category...</option>
                                                    <option value="111">Accounting</option>
                                                    <option value="112">Administration &amp; Office Support</option>
                                                    <option value="113">Agriculture, Animals &amp; Conservation</option>
                                                    <option value="114">Architecture &amp; Design</option>
                                                    <option value="115">Banking &amp; Financial Services</option>
                                                    <option value="116">Communications, Advertising, Arts &amp; Media
                                                    </option>
                                                    <option value="117">Community Services</option>
                                                    <option value="118">Construction</option>
                                                    <option value="119">Customer Service &amp; Call Centre</option>
                                                    <option value="123">Defence &amp; Protective Services</option>
                                                    <option value="120">Education &amp; Training</option>
                                                    <option value="121">Engineering</option>
                                                    <option value="122">Executive &amp; General Management</option>
                                                    <option value="130">Health &amp; Medical</option>
                                                    <option value="124">Hospitality &amp; Tourism</option>
                                                    <option value="125">Human Resources &amp; Recruitment</option>
                                                    <option value="126">Information &amp; Communication Technology
                                                        (ICT)
                                                    </option>
                                                    <option value="127">Insurance &amp; Superannuation</option>
                                                    <option value="128">Legal</option>
                                                    <option value="129">Manufacturing</option>
                                                    <option value="131">Mining &amp; Energy</option>
                                                    <option value="132">Real Estate &amp; Property</option>
                                                    <option value="133">Retail</option>
                                                    <option value="134">Sales</option>
                                                    <option value="135">Science</option>
                                                    <option value="136">Sport &amp; Recreation</option>
                                                    <option value="137">Trades &amp; Services</option>
                                                    <option value="138">Transport &amp; Logistics</option>
                                                    <option value="Other"> Other</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Textarea -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="textarea">Job Description

                                            </label>

                                            <div class="col-md-8">

                                                <textarea style="height: 250px" class="form-control" id="textarea"
                                                          name="textarea">Job Description</textarea>

                                                <span class="help-block">Describe the responsibilities ,  experience, skills, or education. </span>

                                            </div>
                                        </div>


                                        <!-- Select Basic -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="Location">Location </label>

                                            <div class="col-md-8">
                                                <input id="Location" name="Location" placeholder="City or Postcode"
                                                       class="form-control input-md" required="" type="text">
                                            </div>
                                        </div>


                                        <!-- Multiple Radios (inline) -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Add Type</label>

                                            <div class="col-md-8">

                                                <select class="form-control" name="type" id="type">
                                                    <option selected="" value="FULLTIME" name="FULLTIME">Full-time
                                                    </option>
                                                    <option value="PARTTIME" name="PARTTIME">Part-time</option>
                                                    <option value="TEMPORARY" name="TEMPORARY">Temporary</option>
                                                    <option value="CONTRACT" name="CONTRACT">Contract</option>
                                                    <option value="INTERNSHIP" name="INTERNSHIP">Internship</option>
                                                    <option value="PERMANENT" name="PERMANENT">Permanent</option>
                                                    <option value="Optional" name="Optional">Optional</option>
                                                </select>


                                            </div>
                                        </div>


                                        <!-- Prepended text-->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="Salary ">Salary </label>

                                            <div class="col-md-4">
                                                <div class="input-group">
                                                    <span class="input-group-addon">$</span>
                                                    <input id="Salary " name="Salary " class="form-control"
                                                           placeholder="Salary " required="" type="text">

                                                    <div class="input-group-btn">


                                                        <button type="button" class="btn btn-secondary dropdown-toggle"
                                                                data-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false">
                                                            Type <span class="caret"></span>
                                                        </button>
                                                        <ul class="dropdown-menu ">
                                                            <li><a class="dropdown-item">per hour</a></li>
                                                            <li><a class="dropdown-item">per hour</a></li>
                                                            <li><a class="dropdown-item">per month</a></li>
                                                        </ul>
                                                    </div>
                                                </div>


                                            </div>
                                            <div class="col-md-4">
                                                <div class="checkbox">
                                                    <label>
                                                        <input type="checkbox">
                                                        Negotiable </label>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="content-subheading"><i class="icon-user fa"></i> <strong>Company
                                            information</strong></div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="textinput-name">Name</label>

                                            <div class="col-md-8">
                                                <input id="textinput-name" name="textinput-name"
                                                       placeholder="Seller Name" class="form-control input-md"
                                                       required="" type="text">
                                            </div>
                                        </div>

                                        <!-- Appended checkbox -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="seller-email"> Company
                                                Email</label>

                                            <div class="col-md-8">
                                                <input id="Company-email" name="Company-email" class="form-control"
                                                       placeholder="Email" required="" type="text">

                                                <div class="checkbox">
                                                    <label>
                                                        <input type="checkbox" value="">
                                                        <small> Hide the phone number on this jobs.</small>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label" for="seller-Number">Phone
                                                Number</label>

                                            <div class="col-md-8">
                                                <input id="seller-Number" name="seller-Number"
                                                       placeholder="Phone Number" class="form-control input-md"
                                                       required="" type="text">
                                            </div>
                                        </div>


                                        <div class="well">
                                            <h3><i class=" icon-certificate icon-color-1"></i> Make your Ad Premium
                                            </h3>

                                            <p>Premium jobs help promote their service by getting their ads more
                                                visibility with more
                                                job candidate what they want faster. <a href="help.html">Learn more</a>
                                            </p>

                                            <div class="form-group">
                                                <table class="table table-hover checkboxtable">
                                                    <tr>
                                                        <td>
                                                            <div class="radio">
                                                                <label>
                                                                    <input type="radio" name="optionsRadios"
                                                                           id="optionsRadios0" value="option0" checked>
                                                                    <strong>Regular List </strong> </label>
                                                            </div>
                                                        </td>
                                                        <td><p>$00.00</p></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="radio">
                                                                <label>
                                                                    <input type="radio" name="optionsRadios"
                                                                           id="optionsRadios1" value="option1">
                                                                    <strong>Urgent Jobs </strong> </label>
                                                            </div>
                                                        </td>
                                                        <td><p>$10.00</p></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="radio">
                                                                <label>
                                                                    <input type="radio" name="optionsRadios"
                                                                           id="optionsRadios2" value="option2">
                                                                    <strong>Top of the Page Ad </strong> </label>
                                                            </div>
                                                        </td>
                                                        <td><p>$20.00</p></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="radio">
                                                                <label>
                                                                    <input type="radio" name="optionsRadios"
                                                                           id="optionsRadios3" value="option3">
                                                                    <strong>Top of the Page Ad + Urgent Ad </strong>
                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td><p>$40.00</p></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group">
                                                                <div class="col-md-8">
                                                                    <select class="form-control" name="Method"
                                                                            id="PaymentMethod">
                                                                        <option value="2">Select Payment Method</option>
                                                                        <option value="3">Credit / Debit Card</option>
                                                                        <option value="5">Paypal</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td><p><strong>Payable Amount : $40.00</strong></p></td>
                                                    </tr>
                                                </table>

                                            </div>
                                        </div>

                                        <!-- terms -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Terms</label>

                                            <div class="col-md-8">
                                                <label class="checkbox-inline" for="checkboxes-0">
                                                    <input name="checkboxes" id="checkboxes-0"
                                                           value="Remember above contact information." type="checkbox">
                                                    Remember above contact information. </label>
                                            </div>
                                        </div>

                                        <!-- Button  -->
                                        <div class="form-group">
                                            <label class="col-md-3 control-label"></label>

                                            <div class="col-md-8"><a href="posting-success.html" id="button1id"
                                                                     class="btn btn-success btn-lg">Submit</a></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.page-content -->

                <div class="col-md-3 reg-sidebar">
                    <div class="reg-sidebar-inner text-center">
                        <div class="promo-text-box"><i class=" icon-lamp fa fa-4x icon-color-1"></i>

                            <h3><strong>Effective Job Postings </strong></h3>

                            <p> The difference between finding mediocre candidates and extraordinary candidates for your
                                clients is a good job posting. </p>
                        </div>

                        <div class="panel sidebar-panel">
                            <div class="panel-heading uppercase">
                                <small><strong> Job Posting Tips</strong></small>
                            </div>
                            <div class="panel-content">
                                <div class="panel-body text-left">
                                    <ul class="list-check">
                                        <li> Add Keywords</li>
                                        <li> Use Familiar Job Titles</li>
                                        <li> Give Them Details</li>
                                        <li> Expand Your Location</li>
                                        <li> Easy Read Postings</li>
                                        <li> Keep it simple and expected</li>

                                    </ul>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <!--/.reg-sidebar-->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.main-container -->

    <div class="footer" id="footer">
        <div class="container">
            <ul class=" pull-left navbar-link footer-nav">
                <li><a href="index.html"> Home </a> <a href="about-us.html"> About us </a> <a href="#"> Terms and
                    Conditions </a> <a href="#"> Privacy Policy </a> <a href="contact.html"> Contact us </a> <a
                        href="faq.html"> FAQ </a>
            </ul>
            <ul class=" pull-right navbar-link footer-nav">
                <li> &copy; 2015 JobClassified</li>
            </ul>
        </div>

    </div>
    <!--/.footer-->
</div>
<!-- /.wrapper -->

<!-- Le javascript
================================================== -->

<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>


<!-- include carousel slider plugin  -->
<script src="../assets/js/owl.carousel.min.js"></script>


<!-- include equal height plugin  -->
<script src="../assets/js/jquery.matchHeight-min.js"></script>

<!-- include jquery list shorting plugin plugin  -->
<script src="../assets/js/hideMaxListItem.js"></script>

<!-- include jquery.fs plugin for custom scroller and selecter  -->
<script src="../assets/plugins/jquery.fs.scroller/jquery.fs.scroller.js"></script>
<script src="../assets/plugins/jquery.fs.selecter/jquery.fs.selecter.js"></script>
<!-- include custom script for site  -->
<script src="../assets/js/script.js"></script>
</body>
</html>
