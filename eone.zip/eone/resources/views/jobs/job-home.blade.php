<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="../assets/ico/favicon.png">
    <title>BOOTCLASIFIED - Responsive Classified Theme</title>
    <!-- Bootstrap core CSS -->
    <link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../assets/css/style.css" rel="stylesheet">

    <!-- styles needed for carousel slider -->
    <link href="../assets/css/owl.carousel.css" rel="stylesheet">
    <link href="../assets/css/owl.theme.css" rel="stylesheet">

    <!-- Just for debugging purposes. -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- include pace script for automatic web page progress bar  -->

    <script>
        paceOptions = {
            elements: true
        };
    </script>
    <script src="../assets/js/pace.min.js"></script>
</head>
<body>

<div id="wrapper">
    <div class="header">
        <nav class="navbar   navbar-site navbar-default" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span
                            class="icon-bar"></span> <span class="icon-bar"></span></button>
                    <a href="job-home.blade.php" class="navbar-brand logo logo-title">
                        <!-- Original Logo will be placed here  -->
                        <span class="logo-icon"><i class="icon icon-search-1 ln-shadow-logo shape-0"></i> </span>
                        JOB<span>CLASSIFIED </span> </a></div>
                <div class="navbar-collapse collapse">

                    <ul class="nav navbar-nav navbar-left">


                        <li><a href="job-list.blade.php">Browse Jobs</a></li>
                        <li><a href="">Add Resume</a></li>

                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="job-login.blade.php">Login</a></li>
                        <li><a href="job-signup.blade.php">Sign Up</a></li>
                        <li class="postadd"><a class="btn btn-block   btn-border btn-post btn-danger"
                                               href="job-post.blade.php">Post A Job</a></li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
    </div>
    <!-- /.header -->

    <div class="intro jobs-intro hasOverly"
         style="background-image: url(images/jobs/1.jpg); background-position: center center;">
        <div class="dtable hw100">
            <div class="dtable-cell hw100">
                <div class="container text-center">
                    <h1 class="intro-title animated fadeInDown"> Find the Right Job </h1>

                    <p class="sub animateme fittext3 animated fadeIn"> Find the latest jobs available in your area. </p>

                    <div class="row search-row animated fadeInUp">
                        <div class="col-lg-4 col-sm-4 search-col relative locationicon">
                            <i class="icon-location-2 icon-append"></i>
                            <input type="text" name="country" id="autocomplete-ajax"
                                   class="form-control locinput input-rel searchtag-input has-icon"
                                   placeholder="city, state, or zip" value="">

                        </div>
                        <div class="col-lg-4 col-sm-4 search-col relative"><i class="icon-docs icon-append"></i>
                            <input type="text" name="ads" class="form-control has-icon"
                                   placeholder="job title, keywords or company" value="">
                        </div>
                        <div class="col-lg-4 col-sm-4 search-col">
                            <button class="btn btn-primary btn-search btn-block"><i class="icon-search"></i><strong>Find
                                Jobs</strong></button>
                        </div>
                    </div>

                    <div class="resume-up">
                        <a><i class="icon-doc-4"></i></a> <a><b>Upload your CV</b></a> and easily apply to jobs from any
                        device!
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- /.intro -->

    <div class="main-container">
        <div class="container">


            <div class="col-lg-12 content-box ">
                <div class="row row-featured row-featured-category row-featured-company">
                    <div class="col-lg-12  box-title no-border">
                        <div class="inner"><h2><span>Featured</span>
                            companies <a class="sell-your-item" href="job-list.blade.php"> See all companies <i
                                    class="  icon-th-list"></i> </a></h2>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/10.jpg">
                            <h6> Jobs at <span class="company-name">Bluth Company</span> <span
                                    class="jobs-count text-muted">(64)</span>
                            </h6>
                        </a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/11.jpg"> <h6> Jobs at <span
                                class="company-name">Mainway</span> <span class="jobs-count text-muted">(64)</span></h6>
                        </a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/12.jpg">
                            <h6> Jobs at <span class="company-name">W&amp;P</span> <span class="jobs-count text-muted">(64)</span>
                            </h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/23.jpg"> <h6> Jobs at <span
                                class="company-name">Fuels</span> <span class="jobs-count text-muted">(64)</span></h6>
                        </a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/13.jpg">
                            <h6> Jobs at <span class="company-name">Axis Co.</span> <span class="jobs-count text-muted">(64)</span>
                            </h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/14.jpg">
                            <h6> Jobs at <span class="company-name">Videlectrix</span> <span
                                    class="jobs-count text-muted">(64)</span></h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/15.jpg"> <h6> Jobs at <span
                                class="company-name">Blammo</span> <span class="jobs-count text-muted">(64)</span></h6>
                        </a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/16.jpg">
                            <h6> Jobs at <span class="company-name">Incom Co.</span> <span
                                    class="jobs-count text-muted">(64)</span></h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/17.jpg">
                            <h6> Jobs at <span class="company-name">Data System</span> <span
                                    class="jobs-count text-muted">(64)</span></h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/18.jpg">
                            <h6> Jobs at <span class="company-name">Sample inc</span> <span
                                    class="jobs-count text-muted">(64)</span></h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/19.jpg">
                            <h6> Jobs at <span class="company-name">Globex</span> <span class="jobs-count text-muted">(64)</span>
                            </h6></a>
                    </div>

                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
                        <a href="job-list.blade.php"><img alt="img" class="img-responsive"
                                                          src="images/jobs/company-logos/20.jpg">
                            <h6> Jobs at <span class="company-name">LuthorCorp</span> <span
                                    class="jobs-count text-muted">(64)</span></h6></a>
                    </div>

                </div>
            </div>

            <div style="clear: both"></div>

            <div class="row">


                <div class="col-sm-9 page-content col-thin-right">
                    <div class="content-box col-lg-12">
                        <div class="row row-featured row-featured-category">
                            <div class="col-lg-12  box-title no-border">
                                <div class="inner"><h2><span>Latest</span>
                                    Jobs <a href="job-list.blade.php" class="sell-your-item"> View more <i
                                            class="  icon-th-list"></i> </a></h2>
                                </div>
                            </div>

                            <div class="adds-wrapper jobs-list">
                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/1.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">CO Engineering</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php"> Front-end Developer </a>
                                            </h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> New York, NY </span> <span
                                                    class="date"><i class=" icon-clock"> </i>Full-time</span><span
                                                    class=" salary">	<i class=" icon-money"> </i> $50000 - $81000 a year</span></span>

                                            <div class="jobs-desc">
                                                A Web Tester / Developer with experience in PHP, HTML, CSS and
                                                JavaScript is needed to join a global music services company.
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->

                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/2.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">XIAO Co.</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php">UI/UX Front-End Web
                                                Developer </a></h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> New York, NY </span> <span
                                                    class="date"><i class=" icon-clock"> </i>Full-time</span><span
                                                    class=" salary">	<i class=" icon-money"> </i> $10000 - $23000 a year</span></span>

                                            <div class="jobs-desc"> We are seeking a talented UI/UX Front End Web
                                                Developer to design, develop, support web app software. UI/UX Front-End
                                                Web Developer....
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->


                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/23.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">Thatherton Fuels</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php">Javascript Developer</a>
                                            </h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> New York, NY </span> <span
                                                    class="date"><i class=" icon-clock"> </i>Contract </span><span
                                                    class=" salary">	<i class=" icon-money"> </i>$50.00 - $60.00 / Hr</span></span>

                                            <div class="jobs-desc">You’re obsessed with creating scalable applications
                                                using Java. 5+ years of professional coding experience with Java. PKI
                                                and Security Software....
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->


                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/4.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">Praxis corporation</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php">Web Developer Jr. - Front
                                                End</a></h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> Barrington, IL</span> <span
                                                    class="date"><i class=" icon-clock"> </i>Full-time</span><span
                                                    class=" salary">	<i class=" icon-money"> </i> $20000 - $41000 a year</span></span>

                                            <div class="jobs-desc"> Our developers work out of our offices in New York,
                                                Washington DC, Los Angeles, Oakland, Boston, and London. We're looking
                                                for a front-end web developer to join...
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->


                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/5.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">Bluth Company</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php">UI/Web Developer</a></h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> New York, NY </span> <span
                                                    class="date"><i class=" icon-clock"> </i>Full-time</span><span
                                                    class=" salary">	<i class=" icon-money"> </i> $50000 - $70000 a year</span></span>

                                            <div class="jobs-desc"> Delivering a complete front end application. We are
                                                looking for an AngularJS/Web Developer responsible for the client side
                                                of our service....
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->


                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/17.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">Data Systems Ltd.</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php">Full Stack Engineer,
                                                International</a></h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> Mountain View, OR</span> <span
                                                    class="date"><i class=" icon-clock"> </i>Full-time</span><span
                                                    class=" salary">	<i class=" icon-money"> </i> $30000 - $51000 a year</span></span>

                                            <div class="jobs-desc"> You believe in the transformative power education
                                                brings to people's lives, and know how to create the code that will
                                                further opportunities for these lifelong...
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->


                                <div class="item-list job-item">


                                    <div class="col-sm-1  col-xs-2 no-padding photobox">
                                        <div class="add-image"><a href=""><img alt="company logo"
                                                                               src="images/jobs/company-logos/14.jpg"
                                                                               class="thumbnail no-margin"></a></div>
                                    </div>
                                    <!--/.photobox-->
                                    <div class="col-sm-10  col-xs-10  add-desc-box">
                                        <div class="add-details jobs-item">
                                            <h5 class="company-title "><a href="">Videlectrix Ltd.</a></h5>
                                            <h4 class="job-title"><a href="job-details.blade.php">Java Engineer </a></h4>
                                            <span class="info-row">  <span class="item-location"><i
                                                    class="fa fa-map-marker"></i> San Francisco </span> <span
                                                    class="date"><i class=" icon-clock"> </i>Full-time</span><span
                                                    class=" salary">	<i class=" icon-money"> </i> $30000 - $51000 a year</span></span>

                                            <div class="jobs-desc"> Java C/C++, Python. 5+ years of backend software
                                                development experience. Projects include real time data synchronization,
                                                identity management, large...
                                            </div>


                                            <div class="job-actions">
                                                <ul class="list-unstyled list-inline">
                                                    <li>
                                                        <a class="save-job" href="#">
                                                            <span class="fa fa-star-o"></span>
                                                            Save Job
                                                        </a>
                                                    </li>
                                                    <li class="saved-job hide">
                                                        <a href="#" class="saved-job">
                                                            <span class="fa fa-star"></span>
                                                            Saved Job
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="email-job">
                                                            <i class="fa fa-envelope"></i>
                                                            Email Job
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>
                                    <!--/.add-desc-box-->

                                    <!--/.add-desc-box-->
                                </div>
                                <!--/.job-item-->


                            </div>

                            <div class="tab-box  save-search-bar text-center"><a class="text-uppercase"
                                                                                 href="job-list.blade.php"> <i
                                    class=" icon-briefcase "></i> View all jobs </a></div>
                        </div>

                    </div>
                </div>

                <div class="col-sm-3 page-sidebar col-thin-left">
                    <aside>
                        <div class="inner-box no-padding">
                            <div class="inner-box-content"><a href="#"><img class="img-responsive"
                                                                            src="images/site/app.jpg" alt="tv"></a>
                            </div>
                        </div>
                        <div class="inner-box">
                            <h2 class="title-2">Top Job Categories </h2>

                            <div class="inner-box-content">
                                <ul class="cat-list arrow">
                                    <li><a href="job-list.blade.php">Engineering jobs <span class="count">12,578</span> </a>
                                    </li>
                                    <li><a href="job-list.blade.php">Estate Agency jobs <span class="count">4,546</span> </a>
                                    </li>
                                    <li><a href="job-list.blade.php">Financial Services jobs <span class="count">9,115</span></a>
                                    </li>
                                    <li><a href="job-list.blade.php">Banking jobs <span class="count">1,468</span></a></li>
                                    <li><a href="job-list.blade.php">Security &amp; Safety jobs <span
                                            class="count">723</span></a></li>
                                    <li><a href="job-list.blade.php">Graduate jobs <span class="count">18,514</span></a></li>
                                    <li><a href="job-list.blade.php">Health &amp; Medicine jobs <span
                                            class="count">10,621</span></a></li>
                                    <li><a href="job-list.blade.php">Training jobs <span class="count">651</span></a></li>
                                    <li><a href="job-list.blade.php">Hospitality &amp; Catering jobs <span class="count">7,585</span></a>
                                    </li>
                                    <li><a href="job-list.blade.php">Human Resources jobs <span
                                            class="count">3,768</span></a></li>
                                    <li><a href="job-list.blade.php">IT &amp; Telecoms jobs <span class="count">17,242</span></a>
                                    </li>
                                    <li><a href="job-list.blade.php">IT Contractor jobs <span class="count">2,102</span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="inner-box no-padding"><img class="img-responsive" src="images/add2.jpg" alt="">
                        </div>
                    </aside>
                </div>
            </div>

            <div style="clear: both"></div>
            <div class="col-lg-12 content-box ">
                <div class="row row-featured">

                    <div style="clear: both"></div>

                    <div class=" relative  content  clearfix">


                        <div class="">
                            <div class="tab-lite">

                                <!-- Nav tabs -->
                                <ul role="tablist" class="nav nav-tabs ">
                                    <li class="active" role="presentation"><a data-toggle="tab" role="tab"
                                                                              aria-controls="tab1" href="#tab1"
                                                                              aria-expanded="true"><i
                                            class="icon-location-2"></i>Top Job Locations</a></li>
                                    <li role="presentation" class=""><a data-toggle="tab" role="tab"
                                                                        aria-controls="tab2" href="#tab2"
                                                                        aria-expanded="false"><i
                                            class="icon-briefcase"></i>Top Job Titles</a></li>
                                    <li role="presentation" class=""><a data-toggle="tab" role="tab"
                                                                        aria-controls="tab3" href="#tab3"
                                                                        aria-expanded="false"><i
                                            class="icon-commerical-building"></i>Top Companies</a></li>
                                </ul>

                                <!-- Tab panes -->
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="tab1">

                                        <div class="col-lg-12 tab-inner">

                                            <div class="row">
                                                <ul class="cat-list col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php">Atlanta</a></li>
                                                    <li><a href="job-list.blade.php"> Dallas </a></li>
                                                    <li><a href="job-list.blade.php"> New York </a></li>
                                                    <li><a href="job-list.blade.php">Santa Ana/Anaheim </a></li>
                                                    <li><a href="job-list.blade.php">Wichita </a></li>
                                                    <li><a href="job-list.blade.php"> Anchorage </a></li>

                                                    <li><a href="job-list.blade.php"> Miami </a></li>
                                                    <li><a href="job-list.blade.php">Los Angeles</a></li>
                                                </ul>

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php">Boston </a></li>
                                                    <li><a href="job-list.blade.php">Houston</a></li>
                                                    <li><a href="job-list.blade.php">Salt Lake City </a></li>
                                                    <li><a href="job-list.blade.php">Virginia Beach </a></li>
                                                    <li><a href="job-list.blade.php"> San Diego </a></li>

                                                    <li><a href="job-list.blade.php">San Francisco </a></li>
                                                    <li><a href="job-list.blade.php">Tampa </a></li>
                                                    <li><a href="job-list.blade.php"> Washington DC </a></li>

                                                </ul>

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php">Virginia Beach </a></li>
                                                    <li><a href="job-list.blade.php"> San Diego </a></li>
                                                    <li><a href="job-list.blade.php">San Francisco </a></li>
                                                    <li><a href="job-list.blade.php">Tampa </a></li>
                                                    <li><a href="job-list.blade.php"> Washington DC </a></li>
                                                    <li><a href="job-list.blade.php">Boston </a></li>
                                                    <li><a href="job-list.blade.php">Houston</a></li>
                                                    <li><a href="job-list.blade.php">Salt Lake City </a></li>


                                                </ul>

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">

                                                    <li><a href="job-list.blade.php">Salt Lake City </a></li>
                                                    <li><a href="job-list.blade.php">San Francisco </a></li>
                                                    <li><a href="job-list.blade.php">Tampa </a></li>
                                                    <li><a href="job-list.blade.php"> Washington DC </a></li>
                                                    <li><a href="job-list.blade.php">Virginia Beach </a></li>
                                                    <li><a href="job-list.blade.php"> San Diego </a></li>
                                                    <li><a href="job-list.blade.php">Boston </a></li>
                                                    <li><a href="job-list.blade.php">Houston</a></li>

                                                </ul>

                                            </div>

                                        </div>


                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="tab2">

                                        <div class="col-lg-12 tab-inner">

                                            <div class="row">

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php">
                                                        Full Time Jobs

                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Part Time Jobs
                                                        Retail Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Construction Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Marketing Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Accounting Jobs
                                                        Customer Service Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Security Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php">Engineering Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Maintenance Jobs
                                                    </a></li>

                                                </ul>


                                                <ul class="cat-list col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php"> Hospitality Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Government Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Medical Assistant Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Nursing Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Pharmacy Assistant Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Data Entry Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Receptionist Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Welding Jobs
                                                    </a></li>
                                                </ul>

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php"> Criminal Justice Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> HSE Manager Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Pharmaceutical Sales Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Electrician Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Pharmacy Technician Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Graphic Design Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Homeland Security Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> CNA Jobs
                                                    </a></li>

                                                </ul>

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php"> Online Teaching Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Police Officer Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Federal Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Flight Attendant Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Cruise Ship Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php">Housekeeping Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Working at Home Jobs
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Warehouse Work Jobs
                                                    </a></li>

                                                </ul>


                                            </div>

                                        </div>


                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="tab3">

                                        <div class="col-lg-12 tab-inner">

                                            <div class="row">


                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php">
                                                        Aramark Jobs & Careers

                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> AT&T Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Armellini Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Aflac Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Avon Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Aon Service Corporation Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> AmeriBanc National Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> ASML Jobs & Careers
                                                    </a></li>

                                                </ul>


                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php"> Bankers Life Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Comcast Cable Communications Jobs &
                                                        Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Capgemini Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Combined Insurance Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> CNO Services Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Coca Cola Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Doherty Employment Group Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Enterprise Rent-A-Car Jobs & Careers
                                                    </a></li>

                                                </ul>


                                                <ul class="cat-list col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php"> General Electric Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php">Johnson Controls Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Kenan Advantage Group Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Macy's Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> PepsiCo Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Proquire LLC Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Pilot Travel Centers Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> PPG Industries Inc Jobs & Careers
                                                    </a></li>
                                                </ul>

                                                <ul class="cat-list cat-list-border col-sm-3  col-xs-6 col-xxs-12">
                                                    <li><a href="job-list.blade.php"> Quintiles Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> UPS Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Uline Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Safeway Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Seagate Technology Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> Tenet Healthcare Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php">TruGreen Jobs & Careers
                                                    </a></li>
                                                    <li><a href="job-list.blade.php"> UnitedHealth Group Jobs & Careers
                                                    </a></li>

                                                </ul>


                                            </div>

                                        </div>


                                    </div>
                                </div>

                            </div>

                        </div>


                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- /.main-container -->

    <div class="page-info hasOverly"
         style="background-image: url(images/jobs/2.jpg);    background-position: center center;  background-size:cover">
        <div class="bg-overly">
            <div class="container text-center section-promo">
                <div class="row">
                    <div class="col-sm-3 col-xs-6 col-xxs-12">
                        <div class="iconbox-wrap">
                            <div class="iconbox">
                                <div class="iconbox-wrap-icon">
                                    <i class="icon  icon-commerical-building"></i>
                                </div>
                                <div class="iconbox-wrap-content">
                                    <h5><span>2200+</span></h5>

                                    <div class="iconbox-wrap-text">Companies</div>
                                </div>
                            </div>
                            <!-- /..iconbox -->
                        </div>
                        <!--/.iconbox-wrap-->
                    </div>

                    <div class="col-sm-3 col-xs-6 col-xxs-12">
                        <div class="iconbox-wrap">
                            <div class="iconbox">
                                <div class="iconbox-wrap-icon">
                                    <i class="icon  icon-briefcase"></i>
                                </div>
                                <div class="iconbox-wrap-content">
                                    <h5><span>400K+</span></h5>

                                    <div class="iconbox-wrap-text">Live Jobs</div>
                                </div>
                            </div>
                            <!-- /..iconbox -->
                        </div>
                        <!--/.iconbox-wrap-->
                    </div>

                    <div class="col-sm-3 col-xs-6  col-xxs-12">
                        <div class="iconbox-wrap">
                            <div class="iconbox">
                                <div class="iconbox-wrap-icon">
                                    <i class="icon  icon-users"></i>
                                </div>
                                <div class="iconbox-wrap-content">
                                    <h5><span>3000+</span></h5>

                                    <div class="iconbox-wrap-text"> Resume</div>
                                </div>
                            </div>
                            <!-- /..iconbox -->
                        </div>
                        <!--/.iconbox-wrap-->
                    </div>

                    <div class="col-sm-3 col-xs-6 col-xxs-12">
                        <div class="iconbox-wrap">
                            <div class="iconbox">
                                <div class="iconbox-wrap-icon">
                                    <i class="icon icon-doc-1"></i>
                                </div>
                                <div class="iconbox-wrap-content">
                                    <h5><span>2000+</span></h5>

                                    <div class="iconbox-wrap-text"> Resources</div>
                                </div>
                            </div>
                            <!-- /..iconbox -->
                        </div>
                        <!--/.iconbox-wrap-->
                    </div>

                </div>

            </div>
        </div>
    </div>
    <!-- /.page-info -->

    <div class="page-bottom-info">
        <div class="page-bottom-info-inner">

            <div class="page-bottom-info-content text-center">
                <h1>If you have any questions, comments or concerns, please call Career Services
                    at (000) 555-5555</h1>
                <a class="btn  btn-lg btn-primary-dark" href="tel:+000000000">
                    <i class="icon-mobile"></i> <span class="hide-xs color50">Call Now:</span> (000) 555-5555 </a>
            </div>

        </div>
    </div>


    <div class="footer" id="footer">
        <div class="container">
            <ul class=" pull-left navbar-link footer-nav">
                <li><a href="index.html"> Home </a> <a href="about-us.html"> About us </a> <a href="#"> Terms and
                    Conditions </a> <a href="#"> Privacy Policy </a> <a href="contact.html"> Contact us </a> <a
                        href="faq.html"> FAQ </a>
            </ul>
            <ul class=" pull-right navbar-link footer-nav">
                <li> &copy; 2015 jobClassified</li>
            </ul>
        </div>

    </div>
    <!-- /.footer -->
</div>
<!-- /.wrapper -->

<!-- Le javascript
================================================== -->

<!-- Placed at the end of the document so the pages load faster -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>

<!-- include carousel slider plugin  -->
<script src="../assets/js/owl.carousel.min.js"></script>

<!-- include equal height plugin  -->
<script src="../assets/js/jquery.matchHeight-min.js"></script>

<!-- include jquery list shorting plugin plugin  -->
<script src="../assets/js/hideMaxListItem.js"></script>

<!-- include jquery.fs plugin for custom scroller and selecter  -->
<script src="../assets/plugins/jquery.fs.scroller/jquery.fs.scroller.js"></script>
<script src="../assets/plugins/jquery.fs.selecter/jquery.fs.selecter.js"></script>


<!-- include custom script for site  -->
<script src="../assets/js/script.js"></script>

<script>


</script>


<!-- include jquery autocomplete plugin  -->

<script type="text/javascript" src="../assets/plugins/autocomplete/jquery.mockjax.js"></script>
<script type="text/javascript" src="../assets/plugins/autocomplete/jquery.autocomplete.js"></script>
<script type="text/javascript" src="../assets/plugins/autocomplete/usastates.js"></script>

<script type="text/javascript" src="../assets/plugins/autocomplete/autocomplete-demo.js"></script>


</body>
</html>
