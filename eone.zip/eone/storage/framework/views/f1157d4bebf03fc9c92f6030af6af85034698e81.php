<?php $__env->startSection('content'); ?>



<div class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 login-box">
                <div class="panel panel-default">
                    <form class="form" role="form" method="POST" action="<?php echo e(route('login')); ?>">
                    <div class="panel-intro text-center">
                        <h2 class="logo-title">
                            <!-- Original Logo will be placed here  -->
                            <span class="logo-icon"><i
                                        class="icon icon-search-1 ln-shadow-logo shape-0"></i> </span> BOOT<span>CLASSIFIED </span>
                        </h2>
                    </div>
                    <div class="panel-body">

                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                                <label for="email" class="control-label">Username:</label>
                                <div class="input-icon"><i class="icon-user fa"></i>
                                    <input id="email" type="email" placeholder="Username" class="form-control email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>

                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="user-pass" class="control-label">Password:</label>
                                    <div class="input-icon"><i class="icon-lock fa"></i>
                                        <input id="password" type="password" placeholder="Password" class="form-control" name="password" required>
                                    </div>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                            </div>



                            <div class="form-group">

                                    <button type="submit" class="btn btn-primary  btn-block">
                                        Submit
                                    </button>
                            </div>



                    </div>
                    <div class="panel-footer">

                        <div class="checkbox pull-left">

                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Keep me logged in
                            </label>
                        </div>

                        <a class="text-center pull-right" href="<?php echo e(route('password.request')); ?>">
                            Lost your password?
                        </a>



                        <div style=" clear:both"></div>
                    </div>
                    </form>
                </div>
                <div class="login-box-btm text-center">
                    <p> Don't have an account? <br>
                        <a href="<?php echo e(route('register')); ?>"><strong>Sign Up !</strong> </a></p>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>