<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Mail;

class PagesController extends Controller
{

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function contact()
    {
        return view('common.contact');
    }

    public function createContact(Request $request){


        $validator = Validator::make($request->all(), [
            //'first_name' => 'required|unique:posts|max:255',
            'first_name' => 'required|max:255',
            'last_name' => 'max:255',
            'company_name' => 'max:255',
            'email' => 'email|max:255',
            'message' => 'required|max:255'
        ]);

        // print_r($validator);
        //return json_encode($validator->errors()->all());

        if($validator->fails()){

            //return json_encode($validator->errors()->all());
            return redirect('contact')
                ->withErrors($validator)
                ->withInput();
            //return response()->json($validator->messages(), 200);

        }else{

            $data = array(
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'company_name' => $request->company_name,
                'email' => $request->email,
                'message' => $request->message,
            );

           // print_r($data);

            Mail::send('emails.contact',$data,function($message) use ($data){

                $message->from($data['email']);
                $message->to('bertyed@gmail.com');
                $message->subject($data['message']);

            });


            //return redirect()->url('/');

        }



    }

    public function faq()
    {
        return view('common.faq');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
