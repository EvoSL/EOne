<?php

namespace App\Http\Controllers\Auth;

use Mail;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    //protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
       //dd($data);

        return Validator::make($data, [
            'acc_type' => 'required',
            'name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'phone_no' => 'required|max:15',
            'gender' => 'required',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        $confirmation_code = str_random(30);
        $hide_phone_no = (isset($data['hide_phone_no']))?$data['hide_phone_no']:0;

        $user = User::create([
            'acc_type' => $data['acc_type'],
            'name' => $data['name'],
            'last_name' => $data['last_name'],
            'phone_no' => $data['phone_no'],
            'hide_phone_no' => $hide_phone_no,
            'gender' => $data['gender'],
            'about_user' => $data['about_user'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'confirmation_code' => $confirmation_code
        ]);


        $sent = Mail::send('emails.verify', ['confirmation_code' => $confirmation_code], function($message)
        {
            //$message->from('Travel-Mass.com');
            $message->to(Input::get('email'),Input::get('name'))->subject('Verify your email address!');
        });

        return $user;
    }


    public function register(\Illuminate\Http\Request $request)
    {
        // validate the form

        $this->validator($request->all())->validate();

        // add the user
        $this->create($request->all());

        // redirect user
        return redirect($this->redirectPath());
    }




    public function confirm($confirmation_code)
    {

        if(!$confirmation_code)
        {
            throw new InvalidConfirmationCodeException;
        }

        $user = User::whereConfirmationCode($confirmation_code)->first();
        if (!$user)
        {
            throw new InvalidConfirmationCodeException;
        }

        $user->confirmed = 1;
        $user->confirmation_code = null;
        $user->save();

        $currentuser = User::find($user->id);
        if($currentuser->confirmed==1){
            //if(Auth::attempt(['email' => $user->email, 'password' => 'sunjava6.0','confirmed'=>'1'])) {
            Auth::loginUsingId($user->id);
            return Redirect('/home')->with('message', 'You have successfully verified your account.');
            //dd(Auth::check());
        }else{
            //dd(Auth::check());
            return Redirect('/login')->with('message', 'You have not successfully verified your account. Please Login..');
        }

    }
}
