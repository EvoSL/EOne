<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\MainCategory;
use App\SubCategory;

class MainCatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$catagories = MainCategory::all()->take(2);
        $catagories = MainCategory::all();
        //$catagories = \Response::Json($catagories);

        //$sub_categories = SubCategory::all();
        //dd($catagories);


        foreach ($catagories as $catagory) {


            $main_category_arr['main_category_id'] = $catagory->main_category_id;
            $main_category_arr['main_category_name'] = $catagory->main_category_name;

            //echo $catagory->main_category_name.'<br><br>';

            $sub_categories = SubCategory::select('sub_category_id', 'sub_category_name', 'is_popular','icon_image')->where('main_category_id', $catagory->main_category_id)
                ->orderBy('sub_category_name', 'desc')
                ->take(5)
                ->get();

            $data = collect($sub_categories)->toArray();
            array_push($main_category_arr,$data);

            //print_r($main_category_arr).'<br>';

            $main_arr[] = $main_category_arr;

            $main_category_arr = null;
            $data = null;


        }

        //echo json_encode($main_arr);
        echo json_encode($main_arr);

    }

    /**
     * get Category by ID.
     *
     * @return \Illuminate\Http\Response
     */

    public function getCategoryById($main_category_id)
    {
        $catagory = MainCategory::where('main_category_id',$main_category_id)->get();
        $catagory = \Response::Json($catagory);
        echo $catagory;
    }


    /**
     * get Populer Categories.
     *
     * @return \Illuminate\Http\Response
     */

    public function getPopularCategories()
    {
        $pop_catagories = MainCategory::select('main_category_id','main_category_name')->get();
        $pop_catagories = \Response::Json($pop_catagories);
        echo $pop_catagories;
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
