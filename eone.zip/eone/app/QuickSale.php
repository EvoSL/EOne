<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuickSale extends Model
{
    protected $table = 'quicksale';
}
